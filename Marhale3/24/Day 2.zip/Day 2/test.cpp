#include <bits/stdc++.h>
using namespace std;

int main() {
  int mod = 10303;
  int x = 9 * 9 * 9l % mod;
  int tot = 0;
  tot += x % mod + 9ll * x % mod + 81ll * x % mod;
  int ans = 0;
  for(int x = 1, i = 0; i < 6; i++, x = 9ll * x % mod) {
    (ans += x * (6 - i))%= mod;
  }
  cout << ans << endl;
  cout << 9ll * 9 * 9 * 9 * 9 * 9 % mod << endl;
  cout << tot % mod << endl;
  return 0;
}
