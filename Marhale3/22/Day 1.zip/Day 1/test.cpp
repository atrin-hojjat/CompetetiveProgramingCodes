#include <bits/stdc++.h>

int main() {
  char ch = '\u0627';
  int cc = (int) ch;
  std::cout << cc << std::endl;
}
