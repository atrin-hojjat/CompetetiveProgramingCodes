#include <bits/stdc++.h>
using namespace std;

const int delta = 46639;
char chtb[10][10];
int tab[10][10];

void input() {
  for(int i = 0; i < 10; i++)
    for(int j = 0; j < 10; j++)
      cin >> tab[i][j];
}

int main() {
  input();
  return 0;
}
